import Vue from 'vue'
import VTooltip from 'v-tooltip'
import '@/assets/css/v-tooltip.css'
Vue.use(VTooltip)