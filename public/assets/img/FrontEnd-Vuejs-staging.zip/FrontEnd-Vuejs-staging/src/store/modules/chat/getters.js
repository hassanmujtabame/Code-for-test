export default {
  offerPropsalMessages (state) {
    return state.offer_messages
    },
    prepareProjectMessages (state) {
      return state.prepare_project_messages
      },
    onlineUsers (state) {
      return state.online_users
      },
    requestServiceMessages (state) {
      return state.request_service_messages
      },
    messages (state) {
    return state.messages
    },
    chats (state) {
      return state.chats
      }
      
  }