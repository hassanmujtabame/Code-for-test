<template>
     <div style="margin-top: 100px;">
        <div class="container">
            <div class="box bg-white border p-5 shadow">

                <h2 class="d-flex align-items-center">
                    <svg class="mx-2" width="56" height="56" viewBox="0 0 56 56" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <circle cx="28" cy="28" r="28" fill="#1FB9B3"/>
                        <path d="M22.9296 41.1601C22.1957 41.1601 21.4984 40.8663 20.9846 40.3522L10.599 29.9601C9.53472 28.8952 9.53472 27.1325 10.599 26.0676C11.6632 25.0027 13.4247 25.0027 14.489 26.0676L22.9296 34.5135L41.7926 15.6388C42.8568 14.5739 44.6183 14.5739 45.6826 15.6388C46.7468 16.7037 46.7468 18.4663 45.6826 19.5312L24.8746 40.3522C24.3609 40.8663 23.6636 41.1601 22.9296 41.1601Z" fill="white"/>
                    </svg>
                    تهانينا تم الاشتراك بنجاح في 
                    <!-- تهانينا تم الاشتراك بنجاح في  -->
                    <div  class="y-cll border-0 bg-transparent mx-2">
                        الباقة المجانية
                    </div>
                        <button   v-b-modal.modal-1 class="m-c border-0 bg-transparent" style="font-size: 20px;">عرض التفاصيل</button>
                </h2>
                <div class=" pt-4">
                    
                    <a href="../network/subscribe.html" class="btn-custmer-w fw-bolder">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M14.4291 18.82C14.2391 18.82 14.0491 18.75 13.8991 18.6C13.6091 18.31 13.6091 17.83 13.8991 17.54L19.4391 12L13.8991 6.46C13.6091 6.17 13.6091 5.69 13.8991 5.4C14.1891 5.11 14.6691 5.11 14.9591 5.4L21.0291 11.47C21.3191 11.76 21.3191 12.24 21.0291 12.53L14.9591 18.6C14.8091 18.75 14.6191 18.82 14.4291 18.82Z" fill="#1FB9B3"/>
                            <path d="M20.33 12.75H3.5C3.09 12.75 2.75 12.41 2.75 12C2.75 11.59 3.09 11.25 3.5 11.25H20.33C20.74 11.25 21.08 11.59 21.08 12C21.08 12.41 20.74 12.75 20.33 12.75Z" fill="#1FB9B3"/>
                        </svg>
                            العودة للرئيسية  
                            
                    </a>
                </div>
                <div class="mt-5 subscripe-finish">
                    <p class="p-c fs-3">
                        يمكنك  التعرف و الاشتراك في  خدمات رياديات الاخرى   
                    </p>
                    <div  class="sec-tow">
                        <div class=" ">
                          <ul
                            class="nav nav-pills mb-3 gap-5  "
                            id="pills-tab"
                            role="tablist"
                          >
                          <li class="nav-item m-2 col-12 col-md-3" role="presentation">
                            <button
                              class="nav-link active btn-custmer-subscribe  py-3 w-100"
                              id="pills-home-tab"
                              data-bs-toggle="pill"
                              data-bs-target="#pills-home"
                              type="button"
                              role="tab"
                              aria-controls="pills-home"
                              aria-selected="true"
                            >
                            <svg width="49" height="32" viewBox="0 0 49 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M44.2915 27.4576C44.7779 27.9467 45.4584 28.2324 46.1496 28.2345C47.6173 28.2021 48.7928 27.0032 48.8163 25.4992V6.53764C48.8269 5.4383 48.1869 4.46447 47.1864 4.05329L47.18 4.05113C46.1709 3.61831 45.004 3.83688 44.2125 4.60729L38.2947 10.6082V9.30331C38.2947 4.12687 34.2286 0 29.2281 0H9.88305C4.88466 0 0.816406 4.12687 0.816406 9.19727V22.8027C0.816406 27.8753 4.88466 32 9.88305 32H29.2963C34.2947 32 38.363 27.8753 38.363 22.8027V21.487L39.2739 22.3137L44.2915 27.4576ZM35.5896 23.4304L35.5192 23.4195C35.2056 26.657 32.5048 29.1976 29.2345 29.1998H9.88304C6.40358 29.1976 3.57265 26.3259 3.57052 22.7963V9.19734C3.57052 5.66559 6.40145 2.79171 9.88304 2.78955H29.2963C32.7694 2.80253 35.5918 5.67641 35.5896 9.19734L35.5896 23.4304ZM38.3496 17.3795V14.6008L46.068 6.7085V25.274L38.3496 17.3795Z" fill="#979797"/>
                                <path d="M26.3321 14.8371C27.386 15.3716 27.8127 16.6722 27.2857 17.7413C27.0809 18.1589 26.746 18.4987 26.3321 18.7086L16.169 23.8613C15.1151 24.3958 13.833 23.963 13.306 22.8918C13.1588 22.5931 13.082 22.262 13.082 21.9266V11.617C13.082 10.4224 14.0378 9.45292 15.2175 9.45508C15.5482 9.45508 15.8724 9.53298 16.169 9.68231L26.3321 14.8371Z" fill="#979797"/>
                                </svg>
                                
                              الاكاديمية
                            </button>
                          </li>
                            <li class="nav-item m-2 col-12 col-md-3" role="presentation">
                              <button
                              class="nav-link btn-custmer-subscribe w-100 py-3"
                                id="pills-profile-tab"
                                data-bs-toggle="pill"
                                data-bs-target="#pills-profile"
                                type="button"
                                role="tab"
                                aria-controls="pills-profile"
                                aria-selected="false"
                              >
                              <svg width="49" height="48" viewBox="0 0 49 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M21.6206 47.9999C20.1946 47.9999 18.5649 46.7888 18.5649 44.3666V40.1279C18.5649 38.1096 17.5462 36.2927 15.9165 34.8798C12.2494 32.054 10.416 28.0171 10.416 23.5766C10.6197 15.9068 16.9352 9.8512 24.4727 9.64941C28.3435 9.64941 32.0102 11.0623 34.6586 13.6863C37.3071 16.3103 38.9368 19.9437 38.9368 23.7784C38.9368 28.0171 37.1034 32.054 33.6399 34.678C31.8066 36.0909 30.7879 38.3114 30.7879 40.3297V40.9033C30.7881 40.914 30.7883 40.9247 30.7883 40.9354C30.7883 40.9462 30.7881 40.9569 30.7879 40.9675V44.9723C30.7879 46.587 29.3618 47.9999 27.7321 47.9999L21.6206 47.9999ZM20.6013 44.3676C20.6013 44.7716 20.6013 45.9823 21.6201 45.9823H27.7315C28.3429 45.9823 28.7502 45.5788 28.7502 44.9734V41.9458H20.6013V44.3676ZM28.762 39.927C28.8988 37.4207 30.2914 34.7879 32.418 33.0642C35.2701 30.8442 36.8998 27.4126 36.8998 23.7793C36.8998 20.5499 35.6774 17.5223 33.2327 15.1001C30.992 12.88 27.9359 11.6689 24.6765 11.6689C18.1573 11.6689 12.6568 17.1188 12.4531 23.5775C12.4531 27.4126 14.0828 31.046 17.139 33.266C19.3221 35.0362 20.5385 37.3808 20.5996 39.927H28.762ZM43.583 24.7893C42.9716 24.7893 42.5643 24.3857 42.5643 23.7799C42.5643 23.1746 42.9716 22.771 43.583 22.771H47.6575C48.2685 22.771 48.6758 23.1746 48.6758 23.7799C48.6758 24.3857 48.2685 24.7893 47.6575 24.7893H43.583ZM31.8052 23.7795C31.8052 19.9448 28.5458 16.715 24.675 16.715C24.064 16.715 23.6562 16.3115 23.6562 15.7061C23.6562 15.1003 24.064 14.6968 24.675 14.6968C29.7681 14.6968 33.8426 18.7337 33.8426 23.7795C33.8426 24.3853 33.4349 24.7889 32.8239 24.7889C32.2125 24.7889 31.8052 24.3853 31.8052 23.7795V23.7795ZM1.69449 24.7892C1.08311 24.7892 0.675781 24.3857 0.675781 23.7803C0.675781 23.1746 1.08311 22.771 1.69449 22.771H5.76894C6.37993 22.771 6.78726 23.1746 6.78726 23.7803C6.78726 24.3857 6.37993 24.7892 5.76894 24.7892H1.69449ZM37.0633 11.5055C36.656 11.1016 36.656 10.4962 37.0633 10.0926L39.9154 7.26685C40.3231 6.86287 40.9341 6.86287 41.3418 7.26685C41.7492 7.67042 41.7492 8.27578 41.3418 8.67974L38.4893 11.5055C38.4893 11.5055 38.082 11.7073 37.8784 11.7073C37.6747 11.7073 37.2674 11.7073 37.0633 11.5055H37.0633ZM10.6576 11.5053L7.80549 8.47729C7.39817 8.07372 7.39817 7.46837 7.80549 7.0644C8.21282 6.66083 8.8242 6.66083 9.23153 7.0644L12.0836 9.8902C12.4909 10.2942 12.4909 10.8995 12.0836 11.3035C11.8799 11.5053 11.6763 11.7071 11.4726 11.7071C11.269 11.7071 10.8612 11.7071 10.6576 11.5053ZM23.6582 5.04624V1.00932C23.6582 0.403961 24.0655 0 24.6765 0C25.2879 0 25.6952 0.403971 25.6952 1.00932V5.04624C25.6952 5.65161 25.2879 6.05557 24.6765 6.05557C24.0655 6.05557 23.6582 5.6516 23.6582 5.04624Z" fill="#979797"/>
                                </svg>
                                
              
                                الحاضنة
                              </button>
                            </li>
                           
                            <li class="nav-item m-2 col-12 col-md-3" role="presentation">
                              <button
                              class="nav-link btn-custmer-subscribe w-100 py-3"
                                id="pills-servProvider-tab"
                                data-bs-toggle="pill"
                                data-bs-target="#pills-servProvider"
                                type="button"
                                role="tab"
                                aria-controls="pills-servProvider"
                                aria-selected="false"
                              >
                              <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M22.3223 42.9221L22.3205 42.9215C18.5206 41.6183 13.5933 38.6501 9.61731 34.2954C5.64244 29.942 2.625 24.2108 2.625 17.3797C2.625 10.4482 8.22955 4.82471 15.12 4.82471C18.4669 4.82471 21.5949 6.13155 23.9112 8.46772L24 8.55724L24.0888 8.46772C26.4051 6.13155 29.5331 4.82471 32.88 4.82471C39.7703 4.82471 45.375 10.4681 45.375 17.3797C45.375 24.2208 42.3575 29.952 38.3827 34.3029C34.4067 38.655 29.4795 41.6183 25.6794 42.9215L25.6777 42.9221C25.1952 43.0958 24.6105 43.1747 24 43.1747C23.3895 43.1747 22.8048 43.0958 22.3223 42.9221ZM23.2195 40.338L23.2205 40.3383C23.4195 40.4046 23.7203 40.4347 24.01 40.4347C24.2997 40.4347 24.6005 40.4046 24.7995 40.3383L24.8006 40.3379C27.1172 39.5422 31.5736 37.2427 35.4527 33.4263C39.3333 29.6084 42.645 24.2632 42.645 17.3797C42.645 11.9713 38.2697 7.57471 32.9 7.57471C29.8203 7.57471 26.963 9.01358 25.1195 11.5054L25.1194 11.5056C24.867 11.848 24.4478 12.0247 24.02 12.0247C23.5922 12.0247 23.173 11.848 22.9206 11.5056L22.92 11.5047C21.0366 8.99357 18.1998 7.57471 15.12 7.57471C9.75029 7.57471 5.375 11.9713 5.375 17.3797C5.375 24.2532 8.68165 29.5984 12.5598 33.4188C16.4363 37.2376 20.8928 39.5422 23.2195 40.338Z" fill="#979797" stroke="white" stroke-width="0.25"/>
                                </svg>
                                
              
                                مقدمين الخدمات
                              </button>
                            </li>
                         
                          </ul>
                          <div class="tab-content" id="pills-tabContent">
                            <div
                            class="tab-pane fade show active"
                            id="pills-home"
                            role="tabpanel"
                            aria-labelledby="pills-home-tab"
                            tabindex="0"
                          >
                            <div 
                              class="d-flex align-items-center justify-content-between flex-wrap"
                            >
                     
                              <div class=" col-md-6 p-4">
                                <h3 class="p-c">تعرف على الاكاديمية </h3>
                                <p class="p-c">
                                 
                                    نشرح شرح توضيحي بسيط و ملخص يجذب اليوزر انه  يشترك في خدمة أخرى نكتب عن اهمية هذا الخدمة و ممكن تساعده ازاي في تطوير مهاراته و يفضل وضع فيديو توضيحي 
    
                                    نشرح شرح توضيحي بسيط و ملخص يجذب اليوزر انه  يشترك في خدمة أخرى نكتب عن اهمية هذا الخدمة و ممكن تساعده ازاي في تطوير مهاراته و يفضل وضع فيديو توضيحي 
                                </p>
                                <div>
        <router-link class=" btn-custmer"  :to="getRouteLocale('academy-subscribe')">

        
                                      أنضمي الينا الان
        </router-link>
                                </div>
                              </div>
                              <div class="col-md-6 text-start ">
                                
                                <iframe width="420"
                                 height="234" 
                                 class="rounded-3 w-100"
                                 src="https://www.youtube.com/embed/dGG9pWXS3ZQ" 
                                 title="مقطع تعريفي عن شركة رياديات" 
                                 frameborder="0" 
                                 allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                                 allowfullscreen></iframe>                
                                
                                </div>
                            </div>
                          </div>
                            <div
                              class="tab-pane fade"
                              id="pills-profile"
                              role="tabpanel"
                              aria-labelledby="pills-profile-tab"
                              tabindex="0"
                            >
                            <div
                            class="d-flex align-items-center justify-content-between flex-wrap"
                          >
                   
                            <div class=" col-md-6 p-4">
                              <h3 class="p-c">تعرف على الحاضنة </h3>
                              <p class="p-c">
                               
                                  نشرح شرح توضيحي بسيط و ملخص يجذب اليوزر انه  يشترك في خدمة أخرى نكتب عن اهمية هذا الخدمة و ممكن تساعده ازاي في تطوير مهاراته و يفضل وضع فيديو توضيحي 
  
                                  نشرح شرح توضيحي بسيط و ملخص يجذب اليوزر انه  يشترك في خدمة أخرى نكتب عن اهمية هذا الخدمة و ممكن تساعده ازاي في تطوير مهاراته و يفضل وضع فيديو توضيحي 
                              </p>
                              <div>
        <router-link class=" btn-custmer" :to="getRouteLocale('incubator-subscribe')">

      
                                    أنضمي الينا الان
        </router-link>
                              </div>
                            </div>
                            <div class="col-md-6 text-start ">
                              
                              <iframe width="420"
                               height="234" 
                               class="rounded-3 w-100"
                               src="https://www.youtube.com/embed/dGG9pWXS3ZQ" 
                               title="مقطع تعريفي عن شركة رياديات" 
                               frameborder="0" 
                               allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                               allowfullscreen></iframe>                
                              
                              </div>
                          </div>
                            </div>
                           
                            <div
                              class="tab-pane fade"
                              id="pills-servProvider"
                              role="tabpanel"
                              aria-labelledby="pills-servProvider-tab"
                              tabindex="0"
                            >
                            <div
                            class="d-flex align-items-center justify-content-between flex-wrap"
                          >
                   
                            <div class=" col-md-6 p-4">
                              <h3 class="p-c">تعرف على مقدمين الخدمات </h3>
                              <p class="p-c">
                               
                                  نشرح شرح توضيحي بسيط و ملخص يجذب اليوزر انه  يشترك في خدمة أخرى نكتب عن اهمية هذا الخدمة و ممكن تساعده ازاي في تطوير مهاراته و يفضل وضع فيديو توضيحي 
  
                                  نشرح شرح توضيحي بسيط و ملخص يجذب اليوزر انه  يشترك في خدمة أخرى نكتب عن اهمية هذا الخدمة و ممكن تساعده ازاي في تطوير مهاراته و يفضل وضع فيديو توضيحي 
                              </p>
                              <div >
        <router-link class=" btn-custmer" :to="getRouteLocale('service-provider-home')">
      
                                    أنضمي الينا الان
        </router-link>
                              </div>
                            </div>
                            <div class="col-md-6 text-start ">
                              
                              <iframe width="420"
                               height="234" 
                               class="rounded-3 w-100"
                               src="https://www.youtube.com/embed/dGG9pWXS3ZQ" 
                               title="مقطع تعريفي عن شركة رياديات" 
                               frameborder="0" 
                               allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                               allowfullscreen></iframe>                
                              
                              </div>
                          </div>
                            </div>
                         
                          </div>
                        </div>
                      </div>
                </div>
            </div>

        </div>

  <b-modal id="modal-1" title="تفاصيل باقتك"  :hide-footer='true'>

<div class="d-flex rounded-2 border w-100 mb-3">
  <div class="m-c  w-4 px-3 py-2  border-left">أسم الخدمة</div>
  <div class="t-c  w-60 px-3 py-2 ">{{nameSub}} </div>
</div>
<div class="d-flex rounded-2 border w-100 mb-3">
  <div class="m-c  w-4 px-3 py-2  border-left">نوع الباقة</div>
  <div class="t-c  w-60 px-3 py-2 "> مجانية</div>
</div>
<div class="d-flex rounded-2 border w-100 mb-3">
  <div class="m-c  w-4 px-3 py-2  border-left">التفاصيل  </div>
  <div class="t-c  w-60 px-3 pt-2">
    <ul>
      <li class="mb-1">تواصلي مع أعضاء الشبكة</li>
      <li>شاركي في اللقاءات المستمرة لرواد الشبكة</li>
    </ul>
  </div>
</div>
  <div class="d-flex rounded-2 border w-100 mb-3">
  <div class="m-c  w-4 px-3 py-2  border-left">التكلفة</div>
  <div class="t-c  w-60 px-3 py-2 ">ريال0</div>
</div>
<div class="d-flex rounded-2 border w-100 mb-3">
  <div class="m-c  w-4 px-3 py-2  border-left"> وقت الانتهاء</div>
  <div class="t-c  w-60 px-3 py-2 ">{{endDate}} </div>
</div>
  </b-modal>

    </div>
</template>

<script>
export default {
 data:()=>({
endDate:'',
nameSub:''
 }),

  methods:{
      detilsFreePackage(){
               for (let index = 0; index < this.user.system_subscriptions.length; index++) {
                    const element = this.user.system_subscriptions[index];
                    if (element.system_package.name=='مجانا' && element.system_package.related_to.name=='الأكاديمية') {
                        this.endDate=element.end_at
                        this.nameSub= 'أكاديمية رياديات '
                    }
                }
     }
  },
  mounted(){
    this.detilsFreePackage()
  }

}
</script>

<style>
.modal-backdrop{
--bs-backdrop-zindex: none !important;
}
#my-modal___BV_modal_header_ , #my-modal___BV_modal_footer_{
      visibility: hidden !important;
}
.modal-header{
  border: 0 !important;
}
.modal-header button{
  background: transparent !important;
  color: #80808059;
  border: 0;
  font-size: 55px;
}
.border-left{
  border-left: 1px solid #eaeaea;
}
.w-4{
width: 30%;
}
</style>