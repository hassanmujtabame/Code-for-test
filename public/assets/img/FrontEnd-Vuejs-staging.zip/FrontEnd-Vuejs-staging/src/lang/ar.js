export default {
  test: '测试'
}
