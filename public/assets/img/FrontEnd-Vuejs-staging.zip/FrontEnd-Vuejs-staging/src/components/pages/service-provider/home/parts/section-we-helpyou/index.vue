<template>
  <b-container>
    <b-row class="align-items-center mobile-center">
      <b-col lg="6" class=" mobile-hide">
        <div>
          <img class="img-fluid" :src="`${publicPath}assets/img/Group 1171274880.png`" alt />
        </div>
      </b-col>
      <b-col lg="6" class="text">
        <h2 class="fw-bolder">سنساعدك في التقدم</h2>
        <p class="mt-4 w-75" style="color:rgba(151, 151, 151, 1)">مقدمات الخدمات هي أول منصة تجمع مقدمين الخدمات لعرض خدماتهم الخاصة بهم وتحديد المواعيد المناسبة لهم والموقع الجغرافي والتواصل مع العملاء مباشرة عن طريق الموقع و الدفع الالكتروني اسهل مقدمات الخدمات هي أول منصة تجمع مقدمين الخدمات لعرض خدماتهم الخاصة بهم وتحديد المواعيد</p>
        <!-- <p>مقدمات الخدمات هي أول منصة تجمع مقدمين الخدمات لعرض خدماتهم الخاصة بهم وتحديد المواعيد المناسبة لهم والموقع الجغرافي والتواصل مع العملاء مباشرة عن طريق الموقع والدفع الالكتروني اسهل</p> -->
      </b-col>
    </b-row>
  </b-container>
</template>
  

<script>
export default {
  name: "WeHelpYou"
};
</script>

<style>
</style>