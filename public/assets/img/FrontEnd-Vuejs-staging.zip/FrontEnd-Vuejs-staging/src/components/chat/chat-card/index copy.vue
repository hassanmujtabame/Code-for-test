<template>
 <div class="card" id="chat4">
            <div class="card-body" data-mdb-perfect-scrollbar="true"
              style="position: relative; height: 400px">

              <div class="d-flex flex-row justify-content-start">
                <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-chat/ava5-bg.webp"
                  alt="avatar 1" style="width: 45px; height: 100%;">
                <div>
                  <p class="small p-2 ms-3 mb-1 rounded-3" style="background-color: #f5f6f7;">Hi</p>
                  <p class="small p-2 ms-3 mb-1 rounded-3" style="background-color: #f5f6f7;">How are you
                    ...???</p>
                  <p class="small p-2 ms-3 mb-1 rounded-3" style="background-color: #f5f6f7;">What are you
                    doing
                    tomorrow? Can we come up a bar?</p>
                  <p class="small ms-3 mb-3 rounded-3 text-muted">23:58</p>
                </div>
              </div>

              <div class="divider d-flex align-items-center mb-4">
                <p class="text-center mx-3 mb-0" style="color: #a2aab7;">Today</p>
              </div>

              <div class="d-flex flex-row justify-content-end mb-4 pt-1">
                <div>
                  <p class="small p-2 me-3 mb-1 text-white rounded-3 bg-info">Hiii, I'm good.</p>
                  <p class="small p-2 me-3 mb-1 text-white rounded-3 bg-info">How are you doing?</p>
                  <p class="small p-2 me-3 mb-1 text-white rounded-3 bg-info">Long time no see! Tomorrow
                    office. will
                    be free on sunday.</p>
                  <p class="small me-3 mb-3 rounded-3 text-muted d-flex justify-content-end">00:06</p>
                </div>
                <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-chat/ava2-bg.webp"
                  alt="avatar 1" style="width: 45px; height: 100%;">
              </div>

              <div class="d-flex flex-row justify-content-start mb-4">
                <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-chat/ava5-bg.webp"
                  alt="avatar 1" style="width: 45px; height: 100%;">
                <div>
                  <p class="small p-2 ms-3 mb-1 rounded-3" style="background-color: #f5f6f7;">Okay</p>
                  <p class="small p-2 ms-3 mb-1 rounded-3" style="background-color: #f5f6f7;">We will go on
                    Sunday?</p>
                  <p class="small ms-3 mb-3 rounded-3 text-muted">00:07</p>
                </div>
              </div>

              <div class="d-flex flex-row justify-content-end mb-4">
                <div>
                  <p class="small p-2 me-3 mb-1 text-white rounded-3 bg-info">That's awesome!</p>
                  <p class="small p-2 me-3 mb-1 text-white rounded-3 bg-info">I will meet you Sandon Square
                    sharp at
                    10 AM</p>
                  <p class="small p-2 me-3 mb-1 text-white rounded-3 bg-info">Is that okay?</p>
                  <p class="small me-3 mb-3 rounded-3 text-muted d-flex justify-content-end">00:09</p>
                </div>
                <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-chat/ava2-bg.webp"
                  alt="avatar 1" style="width: 45px; height: 100%;">
              </div>

              <div class="d-flex flex-row justify-content-start mb-4">
                <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-chat/ava5-bg.webp"
                  alt="avatar 1" style="width: 45px; height: 100%;">
                <div>
                  <p class="small p-2 ms-3 mb-1 rounded-3" style="background-color: #f5f6f7;">Okay i will meet
                    you on
                    Sandon Square</p>
                  <p class="small ms-3 mb-3 rounded-3 text-muted">00:11</p>
                </div>
              </div>

              <div class="d-flex flex-row justify-content-end mb-4">
                <div>
                  <p class="small p-2 me-3 mb-1 text-white rounded-3 bg-info">Do you have pictures of Matley
                    Marriage?</p>
                  <p class="small me-3 mb-3 rounded-3 text-muted d-flex justify-content-end">00:11</p>
                </div>
                <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-chat/ava2-bg.webp"
                  alt="avatar 1" style="width: 45px; height: 100%;">
              </div>

              <div class="d-flex flex-row justify-content-start mb-4">
                <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-chat/ava5-bg.webp"
                  alt="avatar 1" style="width: 45px; height: 100%;">
                <div>
                  <p class="small p-2 ms-3 mb-1 rounded-3" style="background-color: #f5f6f7;">Sorry I don't
                    have. i
                    changed my phone.</p>
                  <p class="small ms-3 mb-3 rounded-3 text-muted">00:13</p>
                </div>
              </div>

              <div class="d-flex flex-row justify-content-end">
                <div>
                  <p class="small p-2 me-3 mb-1 text-white rounded-3 bg-info">Okay then see you on sunday!!
                  </p>
                  <p class="small me-3 mb-3 rounded-3 text-muted d-flex justify-content-end">00:15</p>
                </div>
                <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-chat/ava2-bg.webp"
                  alt="avatar 1" style="width: 45px; height: 100%;">
              </div>

            </div>
            <div class="card-footer text-muted d-flex justify-content-start align-items-center p-3">
              <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-chat/ava5-bg.webp"
                alt="avatar 3" style="width: 40px; height: 100%;">
              <input type="text" class="form-control form-control-lg" id="exampleFormControlInput3"
                placeholder="Type message">
              <a class="ms-1 text-muted" href="#!"><i class="fas fa-paperclip"></i></a>
              <a class="ms-3 text-muted" href="#!"><i class="fas fa-smile"></i></a>
              <a class="ms-3 link-info" href="#!"><i class="fas fa-paper-plane"></i></a>
            </div>
          </div>
    
</template>

<script>
import showMsg from './show-msg'
import showTime from './show-time'
export default {
  name:'d-chat-card',
  props:{
    item:{}
    
  },
  data:()=>({
    messages:[]
  }),
  components:{
    showMsg,
    showTime
  },
  methods:{
    setTimeDate(datep,time){
      let [hour,minute] = time.split(':')
      datep.setHours(hour);
      datep.setMinutes(minute);
      datep.setSeconds(0);
      return datep.toLocaleString("en-GB")
    },
    addMsg(msg){
      if(this.messages.length==0){
        let m= {
          id:msg.id,
          image:msg.image,
          list:[{...msg}]
        }
        this.messages.push(m)
      }else{
        let last = this.messages[this.messages.length-1]
        if(last.id==msg.id && last.list[last.list.length-1].date==msg.date){
          last.list.push(msg)
        }else{
          let m= {
          id:msg.id,
          image:msg.image,
          list:[{...msg}]
        }
        this.messages.push(m)
        }
       
      }
      
    },
    initializing(){
      let yestarday = new Date();
          yestarday.setDate(yestarday.getDate()-1)
      let today = new Date();

      this.addMsg({id:this.user.id,image:this.user.image,message:'hi',date:this.setTimeDate(yestarday,'23:58'),time:'23:58'})
      this.addMsg({id:this.user.id,image:this.user.image,message:'How are you ...???',date:this.setTimeDate(yestarday,'23:58'),time:'23:58'})
      this.addMsg({id:this.user.id,image:this.user.image,message:'What are you doing tomorrow? Can we come up a bar?',date:this.setTimeDate(yestarday,'23:58'),time:'23:58'})
      
      this.addMsg({id:this.item.id,image:this.item.image,message:"Hiii, I'm good.",date:this.setTimeDate(today,'00:06'),time:'00:06'})
      this.addMsg({id:this.item.id,image:this.item.image,message:"How are you doing?",date:this.setTimeDate(today,'00:06'),time:'00:06'})
      this.addMsg({id:this.item.id,image:this.item.image,message:"Long time no see! Tomorrow office. will be free on sunday.",date:this.setTimeDate(today,'00:06'),time:'00:06'})
      
      this.addMsg({id:this.user.id,image:this.user.image,message:"Okay",date:this.setTimeDate(today,'00:07'),time:'00:07'})
      this.addMsg({id:this.user.id,image:this.user.image,message:"We will go on Sunday?",date:this.setTimeDate(today,'00:07'),time:'00:07'})
      
      this.addMsg({id:this.item.id,image:this.item.image,message:"That's awesome!",date:this.setTimeDate(today,'00:09'),time:'00:09'})
      this.addMsg({id:this.item.id,image:this.item.image,message:"I will meet you Sandon Square sharp at 10 AM",date:this.setTimeDate(today,'00:09'),time:'00:09'})
      this.addMsg({id:this.item.id,image:this.item.image,message:"Is that okay?",date:this.setTimeDate(today,'00:09'),time:'00:09'})

      this.addMsg({id:this.user.id,image:this.user.image,message:"Okay i will meet you on Sandon Square",date:this.setTimeDate(today,'00:011'),time:'00:11'})

      this.addMsg({id:this.item.id,image:this.item.image,message:"Do you have pictures of Matley Marriage?",date:this.setTimeDate(today,'00:011'),time:'00:11'})

      this.addMsg({id:this.user.id,image:this.user.image,message:"Sorry I don't have. i changed my phone.",date:this.setTimeDate(today,'00:013'),time:'00:13'})

      this.addMsg({id:this.item.id,image:this.item.image,message:"Okay then see you on sunday!!",date:this.setTimeDate(today,'00:015'),time:'00:15'})
    }
  },
  mounted(){
  if(process.env.NODE_ENV=='development'){
    this.initializing()
  }
  }
}
</script>

<style scoped>
.form-control {
border-color: transparent;
}
 .form-control:focus {
border-color: transparent;
box-shadow: inset 0px 0px 0px 1px transparent;
}

.divider:after,
.divider:before {
content: "";
flex: 1;
height: 1px;
background: #eee;
}
.card{
width:328px
}
.card-header{
    display: flex;
    padding: 5px 10px;
    align-items: center;
    /*justify-content: space-between;*/
}
.card-body{
    position: relative; 
    height: 347px;
    overflow-y: auto;
}
.chat-avatar{
    height:32px;
    width:32px;
    border-radius: 50%;
    min-height:32px;
    min-width:32px;
  flex-shrink: 0;
}
.chat-title{
    flex:1;
    font-size: .9375rem;
    line-height: 1.3333;
    padding:0 5px;
}
.chat-actions{
    display: flex;
    align-items: center;
    flex-shrink: 0;
}
.bg-my-msg{
    background-color: #f5f6f7;
}
.bg-your-msg{
    background-color: #f5f6f7;
}
</style>