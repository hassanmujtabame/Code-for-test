<template>
<p class="mb-1" v-bind="$attrs">
<slot></slot>
</p>
</template>