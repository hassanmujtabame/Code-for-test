import Vue from 'vue'
import AudioVisual from 'vue-audio-visual'
Vue.use(AudioVisual)