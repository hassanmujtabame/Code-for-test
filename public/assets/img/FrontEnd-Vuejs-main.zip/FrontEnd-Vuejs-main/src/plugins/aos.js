import Vue from 'vue'
import VueAos from 'vue-aos'
Vue.use(VueAos)