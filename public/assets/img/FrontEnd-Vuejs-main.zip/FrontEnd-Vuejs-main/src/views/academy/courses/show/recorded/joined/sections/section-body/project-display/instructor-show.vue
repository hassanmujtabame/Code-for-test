<template>
  <div></div>
</template>

<script>
export default {
name:'display-for-instructor',
 props:['lectureSelected','itemPage']
}
</script>

<style>

</style>