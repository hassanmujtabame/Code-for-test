<template>
  
  <div class="row justify-content-between mt-5 ">
                <div class="col-md-5">
                    <div class="box  ">
                        <div class="row flex-column mt-3 gap-4">
                            <div class="col-md-12 border p-3">
                                    <div class="box d-flex align-items-center justify-content-between ">
                                        <h5 class="m-c">
                                            تقيم خدماتي
                                        </h5>
                                        <p class="m-c">
                                            0
                                        </p>
                                    </div>
                                    <div class="box d-flex align-items-center justify-content-between ">
                                        <button class="btn border rounded-2 bg-transparent">
                                            عرض الطلبات 
                                        </button>
                            
                                    </div>
                            </div>
                            <div class="col-md-12 border mt-3 p-3">
                                <div class="box d-flex align-items-center justify-content-between ">
                                    <h5 style="color: #F2631C;">
                                        طلبات استثمار مشاريعك
                                    </h5>
                                    <p style="color: #F2631C;">
                                        0
                                    </p>
                                </div>
                                <div class="box d-flex align-items-center justify-content-between ">
                                    <button class="btn border rounded-2 bg-transparent">
                                        عرض الكل 
                                    </button>
                  
                                </div>
                        </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="box  ">
                        <div class="row flex-column mt-3 gap-4">
                            <div class="col-md-12 border p-3">
                                    <div class="box d-flex align-items-center justify-content-between ">
                                        <h5 class="y-c">
                                            طلباتك لاستثمار مع الاخرين
                                        </h5>
                                        <p class="y-c">
                                            0
                                        </p>
                                    </div>
                                    <div class="box d-flex align-items-center justify-content-between ">
                                        <button class="btn border rounded-2 bg-transparent">
                                            عرض الكل 
                                        </button>
                                     
                                    </div>
                            </div>
                            <div class="col-md-12 border mt-3 p-3">
                                <div class="box d-flex align-items-center justify-content-between ">
                                    <h5 class="m-c">
                                        تدويناتك
                                    </h5>
                                    <p class="m-c">
                                        0
                                    </p>
                                </div>
                                <div class="box d-flex align-items-center justify-content-between ">
                                    <button class="btn border rounded-2 bg-transparent">
                                        عرض الكل 
                                    </button>
                  
                                </div>
                           </div>
                        </div>
                    </div>
                </div>
            </div>
</template>

<script>
export default {
 name:'section-static'
}
</script>

<style>

</style>