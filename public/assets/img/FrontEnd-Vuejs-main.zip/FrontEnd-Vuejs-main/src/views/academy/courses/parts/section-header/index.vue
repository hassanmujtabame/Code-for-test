<template>
 <div class="main-top p-5 position-relative">
            <h1 class="text-white p-5 fs-1"> أستكشف الدورات </h1>

            <div class="position-absolute anim-hwo-ar-you">
                <img :src="`${publicPath}assets/svg/wave-top.svg`" alt="" />
            </div>
            <div class="star position-absolute">
                <img class="landing" :src="`${publicPath}assets/svg/start.svg`" alt="" />
            </div>
            <div class="square position-absolute">
                <img class="landing" :src="`${publicPath}assets/img/square.png`" alt="" />
            </div>
            <div class="star-two position-absolute">
                <img class="landing" :src="`${publicPath}assets/svg/start.svg`" alt="" />
            </div>
            <div class="star-big position-absolute">
                <img class="landing" :src="`${publicPath}assets/svg/star-big.svg`" alt="" />
            </div>
        </div>
</template>

<script>
export default {
  name:'section-header'
}
</script>

<style>

</style>