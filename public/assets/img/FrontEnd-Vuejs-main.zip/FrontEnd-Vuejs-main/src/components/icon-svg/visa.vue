<template>
<svg width="26" height="26" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
<rect width="26" height="26" fill="url(#patternvisa)"/>
<defs>
<pattern id="patternvisa" patternContentUnits="objectBoundingBox" width="1" height="1">
<use xlink:href="#image0_1232_85334" transform="scale(0.0208333)"/>
</pattern>
<image id="image0_1232_85334" width="48" height="48" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAMAAABg3Am1AAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAABnlBMVEUAAAASZL8SYcEUYr4VZcAVZcAVZcEUZcAVZMAWZcAVZcAVZcAVZcAVZcD////7/f76/P7/+/D5+/71+Pz0+Pzz9/zw9fvv9fvu9Pvu9Prs8vrr8vrq8fno8Pn/7LLj7Pfh6/ff6vbe6fb/5pza5/XY5vXW5PTU4/PR4fPQ4PLP4PLM3fHz3I/L3fHK3PHJ2/DD2O+/1e680+22z+uzzeqyzOqxzOqwy+qvyuquyumtyenrxkyrx+ilxOf+wQz/wQeev+XdvUecvuSaveSZvOSWuuOQtuGPteGNtOCMtODTsC3QrizOri6Gr96Fr96Drd6Crd2BrN2ArN1+qtx6p9t5p9t0o9lzo9lxodlrntdom9aWmFpkmdWRl2Rgl9RfltRdldRdlNNck9OCkGlXkNJVj9FUj9FSjdFQjNBOis9Nis9Mic9KiM5Jh85Ih85EhM1bgYlAgcw9gMs8f8s5fco6erozecgxd8cvdsctdcY8dKEqc8YocsUnccUkb8QnbLIfbMMdasIcasIbacIaaMEYZ8EXZsAXZr4WZsAVZcDMDNS9AAAADnRSTlMAHB0nqaqsr+zt7vDx8r0xoZ0AAAABYktHRA5vvTBPAAABe0lEQVR42u3V/zdTcRzH8TFDsqchbCqtryTCFltL6ItGakNp+boiIowpamrLl8pe/7Ufdu2Xu3O6vzo8f34/zr3nc8/nfW22805vxaVO/TdnmT0/f0GWqig2QKks5jCA0yqoNIAsd7bB74VXL0emj6SDOmp++SGhzIsWd/3dCUlrwA/TE3Yf9fdvSnEI6BZk9m4DMCjpIfDB/ErjN/tmpRB8/uPiqt5D55fkm09SygUMmcEGTU+0f4nr2W/QqSg8yw0N47mGzwz+NtCmOYjqIwxoFbi/IunwCk8DNBY4JT/V20FcPzUGE1KkCghLk7AxCt/N4C3M1PJAegxLkr76gaRauaMlmDODLWiGRanj5BS7YX4dbvT4IGwG2cuA95/koS6beB5fmfLizoTI1VXgSweB11IaWhUBoH455aIjFovdw5M1g3dQlZJWoVcz7e6a5qG0hiEuKQI7Z/0+WF4zFw1QZhWUGMBeYW2+vCi/XB2VFtZeSdH5b+sUdwwBzjMKQxSu9wAAAABJRU5ErkJggg=="/>
</defs>
</svg>
</template>

<script>
export default {
 name:'visa-name'
}
</script>

<style>

</style>