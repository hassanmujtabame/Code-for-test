export default () => ({ 
    isMobile:false,
    isTablet:false,
    isDesktop:false,
    loading:false
 })